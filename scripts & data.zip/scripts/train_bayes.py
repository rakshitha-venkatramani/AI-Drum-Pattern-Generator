import os
import numpy as np
import pandas as pd
import pickle
from pgmpy.models import BayesianNetwork
from pgmpy.estimators import MaximumLikelihoodEstimator

PARSED_DIR = 'data/parsed/'
MODEL_DIR = 'models/'
os.makedirs(MODEL_DIR, exist_ok=True)

SELECTED_DRUMS = ['kick', 'snare', 'closed_hat', 'crash', 'low_tom']

def get_genre_files():
    files = [f for f in os.listdir(PARSED_DIR) if f.endswith('.npy')]
    genre_files = {}
    for f in files:
        genre = f.split('_')[0].lower()
        genre_files.setdefault(genre, []).append(f)
    return genre_files

def train_model_from_files(file_list):
    data = []
    for fname in file_list:
        path = os.path.join(PARSED_DIR, fname)
        try:
            matrix = np.load(path)
            for row in matrix:
                sample = {SELECTED_DRUMS[i]: int(row[i]) for i in range(len(SELECTED_DRUMS))}
                data.append(sample)
        except Exception as e:
            print(f"⚠️ Skipping {fname}: {e}")

    df = pd.DataFrame(data)
    df.fillna(0, inplace=True)
    return df

def train_and_save_bbn(genre, df):
    model = BayesianNetwork([
        ('closed_hat', 'snare'),
        ('closed_hat', 'kick'),
        ('kick', 'snare'),
        ('kick', 'crash'),
        ('snare', 'low_tom'),
    ])
    model.fit(df, estimator=MaximumLikelihoodEstimator)
    model_path = os.path.join(MODEL_DIR, f"{genre}_model.pkl")
    with open(model_path, 'wb') as f:
        pickle.dump(model, f)
    print(f"✅ Trained & saved {genre} model → {model_path}")

if __name__ == '__main__':
    genre_groups = get_genre_files()
    for genre, files in genre_groups.items():
        print(f"\n🎯 Training model for genre: {genre} ({len(files)} files)")
        df = train_model_from_files(files)
        if not df.empty:
            train_and_save_bbn(genre, df)
        else:
            print(f"❌ No usable data for genre '{genre}'. Skipping.")
