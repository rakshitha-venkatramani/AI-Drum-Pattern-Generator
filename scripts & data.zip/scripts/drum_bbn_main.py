import pickle
import os
import random
import pretty_midi
from pgmpy.inference import VariableElimination
from datetime import datetime

# --- Config ---
MODEL_PATH = 'bbn_model.pkl'
OUTPUT_DIR = 'output'
os.makedirs(OUTPUT_DIR, exist_ok=True)
BARS = 3
STEPS_PER_BAR = 16
INSTRUMENTS = ['kick', 'snare', 'closed_hat', 'crash', 'low_tom']
PITCH_MAP = {
    'kick': 36,
    'snare': 38,
    'closed_hat': 42,
    'crash': 49,
    'low_tom': 45
}

# --- Load Trained BBN ---
with open(MODEL_PATH, 'rb') as f:
    model = pickle.load(f)

inference = VariableElimination(model)

# --- Generate Pattern ---
pattern_sequence = []
for i in range(BARS * STEPS_PER_BAR):
    sample = inference.map_query(variables=INSTRUMENTS)
    pattern_sequence.append(sample)

# --- Print Matrix ---
print("\nGenerated Drum Pattern Grid (1 = Hit, 0 = Silent):")
print("Step | " + " | ".join(instr.upper() for instr in INSTRUMENTS))
print("-" * (8 + len(INSTRUMENTS) * 7))

for i, pattern in enumerate(pattern_sequence):
    row = "  {:<2} | ".format(i + 1) + " | ".join(f"  {pattern[instr]}" for instr in INSTRUMENTS)
    print(row)

# --- Create MIDI ---
def generate_midi(pattern_sequence, filename, bpm=120):
    midi = pretty_midi.PrettyMIDI(initial_tempo=bpm)
    drum = pretty_midi.Instrument(program=0, is_drum=True)

    for step, pattern in enumerate(pattern_sequence):
        for instr, hit in pattern.items():
            if hit == 1:
                pitch = PITCH_MAP[instr]
                start = step * 0.25
                end = start + 0.1
                velocity = random.randint(85, 110)
                note = pretty_midi.Note(velocity=velocity, pitch=pitch, start=start, end=end)
                drum.notes.append(note)

    midi.instruments.append(drum)
    midi.write(filename)

# --- Save and Play ---
timestamp = datetime.now().strftime("%H%M%S")
output_path = os.path.join(OUTPUT_DIR, f"generated_loop_{timestamp}.mid")
generate_midi(pattern_sequence, output_path, bpm=120)

print(f"\n✅ Loop saved to {output_path}")
print("🎧 Opening in Windows Media Player...")
os.startfile(output_path)
