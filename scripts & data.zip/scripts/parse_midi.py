import os
import numpy as np
from mido import MidiFile

# Map General MIDI percussion note numbers to instrument names
DRUM_MAP = {
    35: 'kick', 36: 'kick',
    38: 'snare', 40: 'snare',
    42: 'closed_hat', 44: 'pedal_hat', 46: 'open_hat',
    49: 'crash', 51: 'ride', 55: 'splash',
    45: 'low_tom', 47: 'mid_tom', 48: 'high_tom'
}

RAW_DIR = 'data/raw/'
OUT_DIR = 'data/parsed/'
TIME_RESOLUTION = 96  # 96 ticks per quarter note = 1/16 note grid

def parse_midi_to_array(file_path):
    mid = MidiFile(file_path)
    ticks_per_beat = mid.ticks_per_beat
    step = ticks_per_beat // 4  # 1/16th resolution

    events = []
    time = 0
    max_time = 0

    for track in mid.tracks:
        for msg in track:
            time += msg.time
            if msg.type == 'note_on' and msg.velocity > 0 and msg.channel == 9:
                if msg.note in DRUM_MAP:
                    events.append((time, DRUM_MAP[msg.note]))
                    max_time = max(max_time, time)

    instruments = sorted(set(DRUM_MAP.values()))
    instr_idx = {instr: i for i, instr in enumerate(instruments)}
    steps = (max_time // step) + 1
    matrix = np.zeros((steps, len(instruments)), dtype=int)

    for time, instr in events:
        index = time // step
        if instr in instr_idx:
            matrix[index][instr_idx[instr]] = 1

    return matrix, instruments

def batch_parse_with_genre():
    os.makedirs(OUT_DIR, exist_ok=True)

    for root, _, files in os.walk(RAW_DIR):
        for file in files:
            if file.lower().endswith('.mid'):
                full_path = os.path.join(root, file)
                genre = os.path.basename(os.path.dirname(full_path)).lower()
                name = os.path.splitext(file)[0]
                out_file = f"{genre}_{name}.npy"

                try:
                    print(f"🔍 Parsing {file} in genre: {genre}...")
                    matrix, instruments = parse_midi_to_array(full_path)
                    np.save(os.path.join(OUT_DIR, out_file), matrix)
                    print(f"✅ Saved {out_file} | Steps: {matrix.shape[0]} | Drums: {len(instruments)}")
                except Exception as e:
                    print(f"❌ Failed to parse {file}: {e}")

if __name__ == '__main__':
    batch_parse_with_genre()
